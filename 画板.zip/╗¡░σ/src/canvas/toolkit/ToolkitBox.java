package canvas.toolkit;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;

import canvas.CanvasWindow;
import canvas.model.shape.CanvasShape;
/**
 * 
 * �������࣬��������ʻ���ʾ��壬�����ʽ��壬ģ����ʽ�����ڲ���
 *
 */
public class ToolkitBox extends JToolBar implements ActionListener{
	private String[] tipTexts={"���","��Ƥ","�ƶ�","ѡȡ��ɫ","Ǧ��","ֱ��","����","Բ�Ǿ���","��Բ","��ն����","�ı�","�Ŵ�"};
	private String[] fileNames={"fill","eraser","move","getcolor","pencil","line","rect","roundrect","oval","poly", "text", "max"};
	private String[] cursorFileNames={"cross","fill","pencil","getcolor"};
	
	private Image[] cursorIcons=new Image[cursorFileNames.length];
	private ImageIcon[] imgIcons=new ImageIcon[fileNames.length];
	
	
	private JToggleButton[] toolButtons=new JToggleButton[fileNames.length];
	private Cursor[] cursors=new Cursor[cursorFileNames.length];
	
	private Canvas canvas=null;
	private StrokePanel strokePanel=null;//�ʻ���ʾ���
	private ShapeModelPanel shapeModelPanel=null;//ģ�����
	private FillStylePanel fillStylePanel=null;//������
	private EraserPanel eraserPanel=null;//��Ƥ�����
	private int nowShape=CanvasShape.RECTANGLE;//��������ͼ��ģʽ
	
	public ToolkitBox(Canvas canvas) {
		super(JToolBar.VERTICAL);
		this.canvas=canvas;
		JPanel buttonPanel=new JPanel(new GridLayout(fileNames.length/2,2,0,0));
		//�ʻ���ʾ���
		strokePanel=new StrokePanel();
		//ͼ����ʾ���
		shapeModelPanel=new ShapeModelPanel();
		//�����ʽ��ʾ���
		fillStylePanel =new FillStylePanel();
		//��Ƥ��ʾ���
		eraserPanel=new EraserPanel();
		//�õ�������ͼ��
		for(int i=0;i<toolButtons.length;i++){
			imgIcons[i]=new ImageIcon(ToolkitBox.class.getClassLoader().getResource("Icons/"+fileNames[i]+".gif"));
			toolButtons[i]=new JToggleButton(imgIcons[i]);
			toolButtons[i].setToolTipText(tipTexts[i]);
			toolButtons[i].setActionCommand(fileNames[i]);
			toolButtons[i].addActionListener(this);
			buttonPanel.add(toolButtons[i]);
			//Ĭ��ֱ�����ȱ�����
			if(i==5) {
				toolButtons[i].setSelected(true);
			}
		}

		//�õ����ͼ��
		Toolkit systemToolkit=Toolkit.getDefaultToolkit();
		for(int i=0;i<cursors.length;i++){
			cursorIcons[i]=systemToolkit.getImage(ToolkitBox.class.getClassLoader().getResource("cursors/"+cursorFileNames[i]+".gif"));
			cursors[i]=systemToolkit.createCustomCursor(cursorIcons[i], new Point(10,20), cursorFileNames[i]);
		}
		//װ���ڲ������İ�װ���
		JPanel wholePanel=new JPanel(null);
		//������ʱ�̶������ո߶��������
		int toolBarWidth=60;
		int strokePanelHeight=60;
		int buttonPanelHeight=CanvasWindow.WINDOW_HEIGHT/3*2;
		//���ڸ߶�
		int nowHight=0;
		//������߶�
		int interval=5;
		
		wholePanel.setPreferredSize(new Dimension(toolBarWidth+5,CanvasWindow.WINDOW_HEIGHT));
		//����һ����������ڸ߶Ⱦ�����
		buttonPanel.setBounds(0, 0, toolBarWidth, buttonPanelHeight);
		nowHight+=buttonPanelHeight;
		//�ʻ���ʾ�Ļ������
		strokePanel.setBounds(2, nowHight+interval, toolBarWidth, strokePanelHeight);
		strokePanel.setVisible(false);
		//Ϊ�����ۣ��ѱʻ���ʾ���������ʽ������ͬһ��λ��
		fillStylePanel.setBounds(2, nowHight+interval, toolBarWidth, strokePanelHeight);
		fillStylePanel.setVisible(false);
		nowHight+=interval;
		shapeModelPanel.setBounds(2,nowHight+strokePanelHeight+interval,toolBarWidth,60);
		shapeModelPanel.setVisible(false);
		eraserPanel.setBounds(2, nowHight+interval, toolBarWidth, strokePanelHeight);
		eraserPanel.setVisible(false);
		
		wholePanel.add(buttonPanel);
		wholePanel.add(strokePanel);
		wholePanel.add(shapeModelPanel);
		wholePanel.add(eraserPanel);
		wholePanel.add(fillStylePanel);
		wholePanel.setBorder(BorderFactory.createRaisedBevelBorder());
		add(wholePanel);
	}

	/**
	 * ÿ�ΰ�����Ŧ�ͽ����µ����ã�Ȼ���ٲ���
	 *
	 */
	public void reset(){
		for(int i=0;i<toolButtons.length;i++){
			toolButtons[i].setSelected(false);
		}
		strokePanel.setVisible(false);
		shapeModelPanel.setVisible(false);
		fillStylePanel.setVisible(false);
		eraserPanel.setVisible(false);
		canvas.setEraserDown(false);
		canvas.setFillStyle(CanvasShape.NO_FILL_STYLE);
		StateBox.setSelectObject(-1);
		canvas.setText(false);
		canvas.setMoveDown(false);
		canvas.setBrush(false);
		canvas.setFillDown(false);
		canvas.setShapeType(CanvasShape.LINE);
		canvas.setGetColorDown(false);
		canvas.cancelText();
		/*canvas.repaint();*/
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		//���Ȼָ�����
		reset();
		
		
		//�µĲ���
		JToggleButton btn=(JToggleButton)e.getSource();
		btn.setSelected(true);
		String command = e.getActionCommand();
		if(command.equals("pencil")){
			//Ǧ��
			canvas.setShapeType(CanvasShape.PENCIL);
			strokePanel.setVisible(true);
			canvas.setStrokeWidth(strokePanel.selectRow);
			StateBox.setSelectObject(CanvasShape.PENCIL);
		}else if(command.equals("line")){
			//ֱ��
			canvas.setShapeType(CanvasShape.LINE);
			strokePanel.setVisible(true);
			canvas.setStrokeWidth(strokePanel.selectRow);
			StateBox.setSelectObject(CanvasShape.LINE);
		}else if(command.equals("rect")){
			//������
			canvas.setShapeType(CanvasShape.RECTANGLE);
			nowShape=CanvasShape.RECTANGLE;
			strokePanel.setVisible(true);
			shapeModelPanel.setVisible(true);
			canvas.setStrokeWidth(strokePanel.selectRow);
			shapeModelPanel.selectRow=1;
			StateBox.setSelectObject(CanvasShape.RECTANGLE);
		}else if(command.equals("roundrect")){
			//Բ�Ǿ���
			canvas.setShapeType(CanvasShape.ROUND_RECTANGLE);
			nowShape=CanvasShape.ROUND_RECTANGLE;
			strokePanel.setVisible(true);
			shapeModelPanel.setVisible(true);
			canvas.setStrokeWidth(strokePanel.selectRow);
			shapeModelPanel.selectRow=1;
			StateBox.setSelectObject(CanvasShape.ROUND_RECTANGLE);
		}else if(command.equals("oval")){
			//��Բ
			canvas.setShapeType(CanvasShape.ELLIPSE);
			nowShape=CanvasShape.ELLIPSE;
			strokePanel.setVisible(true);
			shapeModelPanel.setVisible(true);
			canvas.setStrokeWidth(strokePanel.selectRow);
			shapeModelPanel.selectRow=1;
			StateBox.setSelectObject(CanvasShape.ELLIPSE);
		}else if(command.equals("poly")){
			//��ն����
			canvas.setShapeType(CanvasShape.POLYLINE);
			strokePanel.setVisible(true);
			shapeModelPanel.setVisible(true);
			canvas.setStrokeWidth(strokePanel.selectRow);
			shapeModelPanel.selectRow=1;
			StateBox.setSelectObject(CanvasShape.POLYLINE);
		}else if(command.equals("eraser")){
			//��Ƥ��
			canvas.setEraserDown(true);
			eraserPanel.setVisible(true);
			canvas.setShapeType(CanvasShape.PENCIL);
			canvas.setStrokeWidth(eraserPanel.selectRow*4.0f);
		}else if(command.equals("move")){
			//�ƶ�
			canvas.setMoveDown(true);
		}else if(command.endsWith("fill")){
			//���
			canvas.setFillDown(true);
			fillStylePanel.setVisible(true);
			fillStylePanel.selectI=1;
			fillStylePanel.selectJ=1;
		}else if(command.endsWith("text")){
			//�ı�
			canvas.setText(true);
			canvas.requestFocus();
		}else if(command.endsWith("max")){
			//�Ŵ�

		}else{//ȡɫ
			canvas.setGetColorDown(true);
		}
			
		getParent().repaint();//�������壬������������ɫ��ȫ���ػ�
		
	}
	/**
	 * ��ʾ�ʻ������
	 */
	public class StrokePanel extends JPanel{
		
		int row=5;//���бʻ�
		int distance=0;
		int selectRow=1;
		public StrokePanel() {
			setBorder(BorderFactory.createLoweredBevelBorder());
			this.addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e) {
					int y=e.getPoint().y;
//System.out.println("Y:"+y);
					selectRow=y/distance+1	;
					canvas.setStrokeWidth(selectRow*1.0f);
					repaint();
//System.out.println("selectRow:"+selectRow);
				}
			});
		}
		
		public void paint(Graphics g){
			super.paint(g);
			int width=this.getWidth();
			int height=this.getHeight();
			distance=height/row;
			g.setColor(Color.BLUE);//��ɫ
			g.fillRect(width/5, (selectRow-1)*distance, width*2/3-3, distance);
			for(int i=1;i<=row;i++){
				if(selectRow==i)
					g.setColor(Color.WHITE);
				else
					g.setColor(Color.BLACK);
				g.fillRect(width/4, distance*i-distance/2, width/2, i/2+1);
			}
		}
	}
	/**
	 * ѡ��ͼ����״
	 * @author Administrator
	 *
	 */
	public class ShapeModelPanel extends JPanel{
		int row=2;
		int distance=0;
		int selectRow=1;
		public ShapeModelPanel() {
			setBorder(BorderFactory.createLoweredBevelBorder());
			this.addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e) {
					int y=e.getPoint().y;
					System.out.println("Y:"+y);
					selectRow=y/distance+1	;
					repaint();
					if(selectRow==1){
						strokePanel.setVisible(true);
						canvas.setFillStyle(CanvasShape.NO_FILL_STYLE);
						fillStylePanel.setVisible(false);
					}else{
						strokePanel.setVisible(false);
						fillStylePanel.setVisible(true);
					}
					repaint();	
//System.out.println("selectRow:"+selectRow);
				}
			});
		}
		
		public void paint(Graphics g){
			
			super.paint(g);
			int width=this.getWidth();
			int height=this.getHeight();
			distance=height/row;
			g.setColor(Color.BLUE);//��ɫ
			g.fillRect(width/7, (selectRow-1)*distance+1, width*2/3, distance-4);
			
			for(int i=1;i<=row;i++){
				if(i==1){// �����ͼ
					g.setColor(Color.BLACK);
					if(nowShape==CanvasShape.RECTANGLE)
						g.drawRect(width/5, distance*(i-1)+distance/5, width/2,distance/2);
					else if(nowShape==CanvasShape.ROUND_RECTANGLE)
						g.drawRoundRect(width/5, distance*(i-1)+distance/5, width/2,distance/2,width/12,height/12);
					else
						g.drawOval(width/5, distance*(i-1)+distance/5, width/2,distance/2);
				}else{//�����ɫ
					g.setColor(Color.GRAY);

					if(nowShape==CanvasShape.RECTANGLE)//����ڲ�
						g.fillRect(width/5, distance*(i-1)+distance/5, width/2,distance/2);
					else if(nowShape==CanvasShape.ROUND_RECTANGLE)
						g.fillRoundRect(width/5, distance*(i-1)+distance/5, width/2,distance/2,width/12,height/12);
					else
						g.fillOval(width/5, distance*(i-1)+distance/5, width/2,distance/2);
				}
					
			}
			
		}
	}
	
	/**
	 * ��ʽ����ʾ������ʽ
	 * @author Administrator
	 *
	 */
	public class FillStylePanel extends JPanel{
		
		int row=2;
		int col=2;
		int distanceWidth=0;
		int distanceHeight=0;
		int selectI=1;
		int selectJ=1;
		
		public FillStylePanel() {
			setBorder(BorderFactory.createLoweredBevelBorder());
			addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e) {
					int y=e.getPoint().y;
					int x=e.getPoint().x;
					selectI=y/distanceHeight+1;
					selectJ=x/distanceWidth+1;
System.out.println("i:"+selectI+"j:"+selectJ);
					repaint();
				}
			});
		}
		
		public void paint(Graphics g){
			super.paint(g);
			int width=getWidth();
			int height=getHeight();
			distanceWidth=width/col-4;
			distanceHeight=height/row-4;
			g.setColor(SystemColor.activeCaption);
			
			if(selectI==1&&selectJ==1){
				canvas.setFillStyle(CanvasShape.FULL_FILL_STYLE);
			}else if(selectI==1&&selectJ==2){
				canvas.setFillStyle(CanvasShape.VERICAL_FILL_STYLE);
			}else if(selectI==2&&selectJ==1){
				canvas.setFillStyle(CanvasShape.HORIZON_FILL_STYLE);
			}else if(selectI==2&&selectJ==2){
				canvas.setFillStyle(CanvasShape.DIAGONAL_FILL_STYLE);
			}
			
			for(int i=1;i<=row;i++){//��������ɫ
				for(int j=1;j<=col;j++){
					if(i==selectI&&j==selectJ)
						g.fillRect(width/16+(j-1)*distanceWidth, height/16+(i-1)*distanceHeight, distanceWidth, distanceHeight);
				}
			}
			Graphics2D g2d=(Graphics2D)g;
			Color foreColor=canvas.colorBox.getForeColor();
			Color backColor=canvas.colorBox.getBackColor();
			
			for(int i=1;i<=row;i++){//�����������е���ʽ
				for(int j=1;j<=col;j++){
					int x1=width/8+(j-1)*distanceWidth;//��ʼ������
					int y1=height/8+(i-1)*distanceHeight;//��ʼ������
					int shape_width=distanceWidth/4*3;//����ͼ�ο���
					int shape_height= distanceHeight/4*3;//����ͼ�θ߶�
					if(i==1&&j==1){//ȫ�����
						g2d.setPaint(foreColor);
					}else if(i==1&&j==2){//��ֱ�������
						GradientPaint gp=new GradientPaint(x1,y1,foreColor,x1,y1+shape_width/2,backColor);
						g2d.setPaint(gp);
					}else if(i==2&&j==1){//ˮƽ�������
						GradientPaint gp=new GradientPaint(x1,y1,foreColor,x1+shape_width/2,y1,backColor);
						g2d.setPaint(gp);	
					}else{//�Խ�
						GradientPaint gp=new GradientPaint(x1,y1,foreColor,x1+shape_width/2,y1+x1+shape_width/2,backColor);
						g2d.setPaint(gp);
					}
					g2d.fillRect(x1, y1, shape_width,shape_height);
				}
			}
		}
		
	}

	
	/**
	 * ��ʾ��Ƥ�����
	 */
	public class EraserPanel extends JPanel{
		int row=4;//4��
		int distance=0;//���ĸ߶�
		int selectRow=1;
		public EraserPanel() {
			setBorder(BorderFactory.createLoweredBevelBorder());
			this.addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e) {
					int y=e.getPoint().y;
//System.out.println("Y:"+y);
					selectRow=y/distance+1	;
					canvas.setStrokeWidth(selectRow*4.0f);
					repaint();
//System.out.println("selectRow:"+selectRow);
				}
			});
			
		}
		
		public void paint(Graphics g){
			super.paint(g);
			int width=this.getWidth();
			int height=this.getHeight();
			distance=height/row;
			
			g.setColor(Color.BLUE);//��ɫ
			g.fillRect(width/3, (selectRow-1)*distance, width/3, distance);
			Graphics2D g2d=(Graphics2D)g;
			
			if(selectRow==1)
				g.setColor(Color.WHITE);
			else
				g.setColor(Color.BLACK);
			g2d.fillOval(width/2-2,distance/2-2, 4, 4);//û�취��λ�������ѿ��ƣ��Ȼ�����һ����
			for(int i=2;i<=row;i++){
				if(selectRow==i)
					g.setColor(Color.WHITE);
				else
					g.setColor(Color.BLACK);
				g2d.fillOval(width/2-i*2,distance*(i-1)+distance/3-6, i*4, i*4);
			}
		}
	}


	/**
	 * �����ַ�����ѡ�����
	 * "cross","fill","pencil","rotate","move" 
	 * @return ���Ӧ�����
	 */
	public Cursor getCustomCursor(String cursorType) {
		int i=0;
		for(;i<cursors.length;i++){
			if(cursors[i].getName().equals(cursorType)){
				break;
			}
		}
		if(i==cursors.length)
			try {
				throw new Exception("���벻��ȷ");
			} catch (Exception e) {
			}
		
		return cursors[i];
	}
}
