package canvas.toolkit;

import canvas.CanvasWindow;
import canvas.dialog.BrushDialog;
import canvas.dialog.MaskDialog;
import canvas.dialog.PasterDialog;
import canvas.util.ImgUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * 
 * ��ֽ��ͼ��ģ��
 *
 */
public class PicBox extends JToolBar implements ActionListener{
	private String[] tipTexts={"��ͼ", "ͼƬģ��", "��ˢ"};
	private String[] fileNames={"paster", "mask", "brush"};
	private String[] cursorFileNames={"cross","fill","pencil","getcolor"};

	private Image[] cursorIcons=new Image[cursorFileNames.length];
	private ImageIcon[] imgIcons=new ImageIcon[fileNames.length];
	private JToggleButton[] toolButtons=new JToggleButton[fileNames.length];
	private Cursor[] cursors = new Cursor[cursorFileNames.length];
	private Canvas canvas = null;
	private PasterDialog pasterDialog;
	private MaskDialog maskDialog;
	private BrushDialog brushDialog;

	public PicBox(Canvas canvas) {
		super(JToolBar.HORIZONTAL);
		this.canvas=canvas;
		pasterDialog = new PasterDialog(canvas);
		maskDialog = new MaskDialog(canvas);
		brushDialog = new BrushDialog(canvas);
		JPanel buttonPanel=new JPanel(new GridLayout(1,fileNames.length,0,0));

		//�õ�������ͼ��
		for(int i=0;i<toolButtons.length;i++){
			Image image = ImgUtil.getImage("/pic/" + fileNames[i] + ".png");
			imgIcons[i]=new ImageIcon(image);
			imgIcons[i].setImage(image.getScaledInstance(30, 30, Image.SCALE_AREA_AVERAGING));
			toolButtons[i]=new JToggleButton(imgIcons[i]);
			toolButtons[i].setToolTipText(tipTexts[i]);
			toolButtons[i].setActionCommand(fileNames[i]);
			toolButtons[i].setPreferredSize(new Dimension(30, 30));
			toolButtons[i].addActionListener(this);
			buttonPanel.add(toolButtons[i]);
		}

		//�õ����ͼ��
		Toolkit systemToolkit=Toolkit.getDefaultToolkit();
		for(int i=0;i<cursors.length;i++){
			cursorIcons[i]=systemToolkit.getImage(PicBox.class.getClassLoader().getResource("cursors/"+cursorFileNames[i]+".gif"));
			cursors[i]=systemToolkit.createCustomCursor(cursorIcons[i], new Point(10,20), cursorFileNames[i]);
		}
		//װ���ڲ������İ�װ���
		JPanel wholePanel=new JPanel(null);
		int toolBarWidth=fileNames.length * 40;
		int buttonPanelHeight=40;
		wholePanel.setPreferredSize(new Dimension(CanvasWindow.WINDOW_WIDTH/2, 40));
		//����һ����������ڸ߶Ⱦ�����
		buttonPanel.setBounds(0, 0, toolBarWidth, buttonPanelHeight);
		wholePanel.add(buttonPanel);
		wholePanel.setBorder(BorderFactory.createRaisedBevelBorder());
		add(wholePanel);
	}

	/**
	 * ÿ�ΰ�����Ŧ�ͽ����µ����ã�Ȼ���ٲ���
	 *
	 */
	public void reset(){
		for(int i=0;i<toolButtons.length;i++){
			toolButtons[i].setSelected(false);
		}
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		//���Ȼָ�����
		reset();
		//�µĲ���
		JToggleButton btn=(JToggleButton)e.getSource();
		btn.setSelected(true);
		String command = e.getActionCommand();
		if(command.equals("paster")){
			canvas.setMoveDown(true);
			pasterDialog.setVisible(true);
		}else if(command.equals("mask")){
			maskDialog.setVisible(true);
		}else if(command.equals("brush")){
			brushDialog.setVisible(true);
		}
	}


	/**
	 * �����ַ�����ѡ�����
	 * "cross","fill","pencil","rotate","move" 
	 * @return ���Ӧ�����
	 */
	public Cursor getCustomCursor(String cursorType) {
		int i=0;
		for(;i<cursors.length;i++){
			if(cursors[i].getName().equals(cursorType)){
				break;
			}
		}
		if(i==cursors.length)
			try {
				throw new Exception("���벻��ȷ");
			} catch (Exception e) {
			}
		
		return cursors[i];
	}
}
