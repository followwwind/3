package canvas.dialog;

import canvas.model.img.CanvasMask;
import canvas.model.img.CanvasPaster;
import canvas.toolkit.Canvas;
import canvas.util.ImgUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * ��ֽ������
 */
public class PasterDialog extends JDialog  implements ActionListener {
    /**
     * ��ֽ����
     */
    private int count = 15;
    private int col = 5;
    private int row = 3;
    private int size = 50;
    private Canvas canvas = null;
    private JToggleButton[] toolButtons=new JToggleButton[count];
    private ImageIcon[] imgIcons = new ImageIcon[count];
    public PasterDialog(Canvas canvas) {
        JPanel buttonPanel = new JPanel(new GridLayout(row, col,0,0));
        this.canvas=canvas;
        //�õ�������ͼ��
        for(int i=0;i < count; i++){
            Image image = ImgUtil.getImage("/paster/" + (i + 1) + ".png");
            imgIcons[i]=new ImageIcon(image);
            imgIcons[i].setImage(image.getScaledInstance(size, size, Image.SCALE_AREA_AVERAGING));
            toolButtons[i]=new JToggleButton(imgIcons[i]);
            toolButtons[i].setActionCommand(String.valueOf(i));
            toolButtons[i].setPreferredSize(new Dimension(size, size));
            toolButtons[i].addActionListener(this);
            buttonPanel.add(toolButtons[i]);
        }
        //װ���ڲ������İ�װ���
        JPanel wholePanel=new JPanel(null);
        int toolBarWidth= col * size;
        int buttonPanelHeight = row * size;
        buttonPanel.setBounds(0, 0, toolBarWidth, buttonPanelHeight);
        wholePanel.add(buttonPanel);
        add(wholePanel);
        setSize(new Dimension(toolBarWidth + 10, buttonPanelHeight + 35));
        setLocationRelativeTo(null);
    }

    /**
     * ÿ�ΰ�����Ŧ�ͽ����µ����ã�Ȼ���ٲ���
     *
     */
    public void reset(){
        for(int i=0;i<toolButtons.length;i++){
            toolButtons[i].setSelected(false);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        reset();
        JToggleButton btn = (JToggleButton)e.getSource();
        btn.setSelected(true);
        String command = e.getActionCommand();
        int i = Integer.parseInt(command);
        ImageIcon imageIcon = this.imgIcons[i];
        canvas.setCanvasPaster(new CanvasPaster(imageIcon));
    }
}
