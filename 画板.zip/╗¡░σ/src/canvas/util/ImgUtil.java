package canvas.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * @package com.candy.util
 * @className ImgUtil
 * @note image util
 * @author wind
 * @date 2020/7/4 10:01
 */
public class ImgUtil {

    private ImgUtil(){

    }

    /**
     * get image
     * @param path
     * @return
     */
    public static Image getImage(String path) {
        BufferedImage bi = null;
        try {
            bi = ImageIO.read(ImgUtil.class.getResourceAsStream(path));
        }catch(IOException e) {
            e.printStackTrace();
        }
        return bi;
    }
}
