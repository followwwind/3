package canvas.model.img;


import javax.swing.*;
import java.awt.*;

/**
 * ��ˢ
 */
public class CanvasBrush extends CanvasImg {


    public CanvasBrush(ImageIcon imageIcon) {
        super(imageIcon);
    }

    @Override
    public void draw(Graphics2D g) {
        g.setStroke(new BasicStroke(10));
        g.drawImage(getImageIcon().getImage(), this.getX(), this.getY(), null);
    }
}
