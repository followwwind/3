package canvas.model.img;


import javax.swing.*;
import java.awt.*;

/**
 * ģ��
 */
public class CanvasPaster extends CanvasImg {


    public CanvasPaster(ImageIcon imageIcon) {
        super(imageIcon);
    }

    @Override
    public void draw(Graphics2D g) {
        g.drawImage(getImageIcon().getImage(), getX(), getY(), null);
    }
}
