package canvas.model.img;


import javax.swing.*;
import java.awt.*;

/**
 * ģ��
 */
public class CanvasMask extends CanvasImg {


    public CanvasMask(ImageIcon imageIcon) {
        super(imageIcon);
    }

    @Override
    public void draw(Graphics2D g) {
        g.drawImage(getImageIcon().getImage(), 0, 0, null);
    }
}
