package canvas.model.img;

import javax.swing.*;
import java.awt.*;

/**
 * ����ͼƬ
 */
public abstract class CanvasImg implements Cloneable {

    private ImageIcon imageIcon;

    /**
     * ��ʼxλ��
     */
    private int x;

    /**
     * ��ʼyλ��
     */
    private int y;

    public CanvasImg(ImageIcon imageIcon) {
        this.imageIcon = imageIcon;
    }

    /**
     * ��ͼ�Σ�����������ʵ��
     * @param g
     */
    public abstract void draw(Graphics2D g);

    public ImageIcon getImageIcon() {
        return imageIcon;
    }

    public void setImageIcon(ImageIcon imageIcon) {
        this.imageIcon = imageIcon;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
}
