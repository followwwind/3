package canvas.model;

import java.awt.*;
import java.awt.geom.Rectangle2D;

/**
 * �ı�
 */
public class CanvasText implements Cloneable{

    private int x;

    private int y;

    private String text;

    private int width;
    private int height;

    private boolean isEnd;

    protected Color color = Color.BLACK;

    public CanvasText() {
        this.width = 100;
        this.height = 30;
        this.text = "";
    }

    public void draw(Graphics2D g) {
        if(!isEnd){
            g.setColor(color);
            float[] dash = {5.0f};
            BasicStroke stroke = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER,
                    10.0f, dash, 0.0f);
            g.setColor(Color.BLACK);
            g.setStroke(stroke);
            g.drawRect(x, y, this.width + this.text.length(), this.height);
        }
        if(text != null && !"".equals(text)){
            g.setColor(color);
            g.drawString(text, x, y + 15);
        }
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public boolean isEnd() {
        return isEnd;
    }

    public void setEnd(boolean end) {
        isEnd = end;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}
