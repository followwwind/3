package canvas.model.shape;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

/**
 * 
 * ��ͼƬ����
 *
 */
public class CanvasImage extends CanvasShape implements Shape{
	Image image=null;
	
	public CanvasImage(int x1,int y1,int width,int height,Image image){
		this.x1=x1;
		this.y1=y1;
		this.width=width;
		this.height=height;
		this.image=image;
		this.shape=this;
	}
	/**
	 * ��ͼƬ�ķ���
	 */
	@Override
	public void draw(Graphics2D g) {
		g.drawImage(image, (int)x1, (int)y1,(int)width,(int)height,null);
		
	}
	/**
	 * �������Ƿ���ͼƬ��
	 */
	public boolean contains(double x, double y) {
		if(x>x1&&y>y1&&x<(x1+width)&&y<(y1+height))
			return true;
		return false;
	}
	
	/**
	 * �����Լ��ĸ���,λ��ƫ��(10,10)
	 * @return ��¡����
	 */
	public CanvasImage clone(){
		return new CanvasImage((int)x1+10,(int)y1+10,(int)width,(int)height,image);
	}
	
	
	public boolean contains(Point2D p) {
		return false;
	}

	public boolean contains(Rectangle2D r) {
		return false;
	}

	public boolean contains(double x, double y, double w, double h) {
		return false;
	}

	public Rectangle getBounds() {
		return null;
	}

	public Rectangle2D getBounds2D() {
		return null;
	}

	public PathIterator getPathIterator(AffineTransform at) {
		return null;
	}

	public PathIterator getPathIterator(AffineTransform at, double flatness) {
		return null;
	}

	public boolean intersects(Rectangle2D r) {
		return false;
	}

	public boolean intersects(double x, double y, double w, double h) {
		return false;
	}

}
