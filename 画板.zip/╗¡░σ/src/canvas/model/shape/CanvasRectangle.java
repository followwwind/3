package canvas.model.shape;

import java.awt.BasicStroke;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
/**
 * �����ε���
 *
 */
public class CanvasRectangle extends CanvasShape{
	Rectangle2D.Float rectangle=null;
	public CanvasRectangle(float x,float y,float width,float height) {
		this.x1=x;
		this.y1=y;
		this.width=width;
		this.height=height;
		rectangle=new Rectangle2D.Float(x1,y1,width,height);
		shape=rectangle;
	}
	/**
	 * �����εķ���
	 */
	@Override
	public void draw(Graphics2D g) {
		rectangle.x=x1;
		rectangle.y=y1;
		rectangle.width=width;
		rectangle.height=height;
		g.setStroke(new BasicStroke(strokeWidth));
		if(fillStyle==NO_FILL_STYLE){
			g.setPaint(nowforeColor);
			g.draw(shape);
			return;
		}
		//�õ���Ӧ����ʽ���
		GradientPaint gp = getFillColor();
		g.setPaint(gp);
		g.fill(shape);
	}
	/**
	 * �����Լ��ĸ���,λ��ƫ��(10,10)
	 * @return ��¡����
	 */
	public CanvasRectangle clone(){
		CanvasRectangle cr=new CanvasRectangle(x1+10,y1+10,width,height);
		cr.fillStyle=fillStyle;
		cr.strokeWidth=strokeWidth;
		cr.nowbackColor=nowbackColor;
		cr.nowforeColor=nowforeColor;
		return cr;
	}
	
	
}
