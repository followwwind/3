package canvas.model.shape;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
/**
 * Ǧ�ʻ�����ͼ�ε���,ûע�͵ķ�������û��ʵ��,ʼ�շ���false����null
 *
 */
public class CanvasPencil extends CanvasShape implements Shape{
	private int x[];
	private int y[];
	private int n;
	
	public CanvasPencil(int x[],int y[]) {
		this.x=x;
		this.y=y;
		this.n=x.length;
		getInfo();	//�õ���ʼ��ͳ�������
		shape=this;
		
	}

	private void getInfo(){//�õ�ֱ����Сx,y���꣬�õ����x,y����
		int minX=x[0];
		int minY=y[0];
		int maxX=minX;
		int maxY=minY;
		
		int x2=0;
	    int y2=0;
		
		for(int i=0;i<x.length;i++){
			if(x[i]<minX)
				minX=x[i];
			if(x[i]>maxX)
				maxX=x[i];
			if(y[i]<minY)
				minY=y[i];
			if(y[i]>maxY)
				maxY=y[i];
		}
		x1=minX;
		y1=minY;
		x2=maxX;
		y2=maxY;
		
		width=Math.abs(x1-x2);
		height=Math.abs(y1-y2);
		
	}
	/**
	 * Ǧ�ʻ�����ͼ��ķ���
	 */
	@Override
	public void draw(Graphics2D g) {
		g.setStroke(new BasicStroke(strokeWidth));
		g.setColor(nowforeColor);
		g.drawPolyline(x, y, n);
	}
	/**
	 * �����Լ��ĸ���,λ��ƫ��(10,10)
	 * @return ��¡����
	 */
	@Override
	public CanvasPencil clone(){
		int[] newXs=new int[x.length];
		int[] newYs=new int[y.length];
		for(int i=0;i<x.length;i++){
			newXs[i]=x[i]+10;
			newYs[i]=y[i]+10;
		}
		CanvasPencil cp=new CanvasPencil(newXs,newYs);
		cp.nowbackColor=nowbackColor;
		cp.nowforeColor=nowforeColor;
		cp.strokeWidth=strokeWidth;
		return cp;
	}
	
	public boolean contains(Point2D p) {
		return false;
	}

	public boolean contains(Rectangle2D r) {
		return false;
	}
	/**
	 * ����Ƿ��ڱ߽���
	 * @return ����ڱ߽�ͷ���true
	 */
	public boolean contains(double testX, double testY) {
		if(testX<x1+width&&testX>x1&&testY<y1+height&&testY>y1)
			return true;
		else
			return false;
	}
	
	/**
	 * �����������򣬷��������ƶ�
	 * @param xdistance
	 * @param ydistance
	 */
	public void movePoly(int xdistance,int ydistance){
		
		float x2=x1+width;
		float y2=y1+height;
		
		x1+=xdistance;
		y1+=ydistance;
		
		
		x2+=xdistance;
		y2+=ydistance;
		
		for(int i=0;i<x.length;i++){
			x[i]+=xdistance;
			y[i]+=ydistance;
		}
	}
	

	public boolean contains(double x, double y, double w, double h) {
		return false;
	}

	public Rectangle getBounds() {
		return null;
	}

	public Rectangle2D getBounds2D() {
		return null;
	}

	public PathIterator getPathIterator(AffineTransform at) {
		return null;
	}

	public PathIterator getPathIterator(AffineTransform at, double flatness) {
		return null;
	}

	public boolean intersects(Rectangle2D r) {
		return false;
	}

	public boolean intersects(double x, double y, double w, double h) {
		return false;
	}

}
