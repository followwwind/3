package canvas.model.shape;

import java.awt.BasicStroke;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Polygon;

/**
 * ����ն���ε���
 *
 */
public class CanvasPolyLine extends CanvasShape{

	private int x[];
	private int y[];
	private int n;
	Polygon polygon=null;
	
	public CanvasPolyLine(int x[],int y[]) {
		this.x=x;
		this.y=y;
		this.n=x.length;
		getInfo();
		polygon=new Polygon(x,y,n);
		shape=polygon;
	}
	
	private void getInfo(){//�õ�ֱ����Сx,y���꣬�õ����x,y����
		int minX=x[0];
		int minY=y[0];
		int maxX=minX;
		int maxY=minY;
		
		int x2=0;
		int y2=0;
		
		for(int i=0;i<x.length;i++){
			if(x[i]<minX)
				minX=x[i];
			if(x[i]>maxX)
				maxX=x[i];
			if(y[i]<minY)
				minY=y[i];
			if(y[i]>maxY)
				maxY=y[i];
		}
		x1=minX;
		y1=minY;
		x2=maxX;
		y2=maxY;
		
		width=Math.abs(x1-x2);
		height=Math.abs(y1-y2);
		
	}
	/**
	 * �����Լ��ĸ���,λ��ƫ��(10,10)
	 * @return ��¡����
	 */
	public CanvasPolyLine clone(){
		int[] newXs=new int[x.length];
		int[] newYs=new int[y.length];
		for(int i=0;i<x.length;i++){
			newXs[i]=x[i]+10;
			newYs[i]=y[i]+10;
		}
		CanvasPolyLine cp=new CanvasPolyLine(newXs,newYs);
		cp.fillStyle=fillStyle;
		cp.strokeWidth=strokeWidth;
		cp.nowbackColor=nowbackColor;
		cp.nowforeColor=nowforeColor;
		return  cp;
	}
	
	/**
	 * ����ն���εķ���
	 */
	public void draw(Graphics2D g) {		
		polygon.xpoints=x;
		polygon.ypoints=y;
		polygon.npoints=n;
		g.setStroke(new BasicStroke(strokeWidth));
		if(fillStyle==NO_FILL_STYLE){
			g.setPaint(nowforeColor);
			g.draw(shape);
			return;
		}
		GradientPaint gp=getFillColor();//�õ���Ӧ����ʽ���
		g.setPaint(gp);
		g.fill(shape);
	}
	
	/**
	 * �����������򣬷��������ƶ�
	 * @param xdistance ������ƫ��
	 * @param ydistance �����ƫ��
	 */
	public void movePoly(int xdistance,int ydistance){
		
		float x2=x1+width;
		float y2=y1+height;
		
		x1+=xdistance;
		y1+=ydistance;
		
		x2+=xdistance;
		y2+=ydistance;

		for(int i=0;i<x.length;i++){
			x[i]+=xdistance;
			y[i]+=ydistance;
		}
	}
	
}
