package canvas.model.shape;

import java.awt.BasicStroke;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.geom.RoundRectangle2D;
/**
 * ��Բ�Ǿ��ε���
 *
 */
public class CanvasRoundRectangle extends CanvasShape{
	RoundRectangle2D.Float roundRect=null;
	public CanvasRoundRectangle(float x,float y,float width,float height) {
		this.x1=x;
		this.y1=y;
		this.width=width;
		this.height=height;
		roundRect=new RoundRectangle2D.Float(x1,y1,width,height, width/2, height/2);
		shape=roundRect;
	}
	/**
	 * ��Բ�Ǿ��εķ���
	 */
	public void draw(Graphics2D g) {
		roundRect.x=x1;
		roundRect.y=y1;
		roundRect.width=width;
		roundRect.height=height;
		roundRect.arcwidth= width/2;
		roundRect.archeight=height/2;
		
		g.setStroke(new BasicStroke(strokeWidth));
		if(fillStyle==NO_FILL_STYLE){
			g.setPaint(nowforeColor);
			g.draw(shape);
			return;
		}
		GradientPaint gp=getFillColor();//�õ���Ӧ����ʽ���
		g.setPaint(gp);
		g.fill(shape);
	}
	/**
	 * �����Լ��ĸ���,λ��ƫ��(10,10)
	 * @return ��¡����
	 */
	public CanvasRoundRectangle clone(){
		CanvasRoundRectangle crr=new CanvasRoundRectangle(x1+10,y1+10,width,height);
		crr.fillStyle=fillStyle;
		crr.strokeWidth=strokeWidth;
		crr.nowbackColor=nowbackColor;
		crr.nowforeColor=nowforeColor;
		return crr;
	}
	
}
