package canvas.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.LinkedList;

import javax.swing.ImageIcon;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import canvas.model.shape.CanvasShape;
import canvas.toolkit.Canvas;

/**
 * �༭�˵�
 * @author Administrator
 *
 */
public class CanvasEditMenu extends JMenu implements ActionListener{
	private Canvas canvas; 
	private String[] itemLabels={"����(U)","����(C)","����(T)","ճ��(P)","ɾ��(D)"};
	private String[] tipTexts={"undo","copy","cut","parse","delete"};
	private JMenuItem[] items=new JMenuItem[tipTexts.length];
	private ImageIcon[] editIcons=new ImageIcon[tipTexts.length];
	private char[] memerys={'U','C','T','P','D'};
	private CanvasShape transferShape=null;
	private LinkedList<CanvasShape> undoShapes=new LinkedList<CanvasShape>();
	
	
	public CanvasEditMenu(Canvas canvas) {
		super("�༭(E)");
		this.canvas=canvas;
		
		for(int i=0;i<tipTexts.length;i++){
			editIcons[i]=new ImageIcon(CanvasEditMenu.class.getClassLoader().getResource("Icons/"+tipTexts[i]+".gif"));
			items[i]=new JMenuItem(itemLabels[i],memerys[i]);
			items[i].setToolTipText(tipTexts[i]);
			items[i].setActionCommand(tipTexts[i]);
			items[i].addActionListener(this);
			items[i].setIcon(editIcons[i]);
			add(items[i]);
			if(i==0)
				addSeparator();
		}

		items[0].setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z,KeyEvent.CTRL_DOWN_MASK));//����
		items[1].setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, KeyEvent.CTRL_DOWN_MASK));//����
		items[2].setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, KeyEvent.CTRL_DOWN_MASK));//����		
		items[3].setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, KeyEvent.CTRL_DOWN_MASK));//ճ��
		items[4].setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE,0));//ɾ��
		
		items[0].setEnabled(false);
		setMnemonic('E');
		
		
	}

	public void actionPerformed(ActionEvent e) {
		if(undoShapes.size()<=1)//����
			items[0].setEnabled(false);
		else
			items[0].setEnabled(true);
		if(e.getActionCommand().equals("undo")){
			undoObeject();
		}else if(e.getActionCommand().equals("copy")){
			saveObject();
		}else if(e.getActionCommand().equals("cut")){
			cutObject();
		}else if(e.getActionCommand().equals("parse")){
			parseObject();
		}else{//delete
			deleteObject();
		}
	}
	/**
	 * ��������
	 *
	 */
	public void saveObject(){
			CanvasShape selectCanvasShape=canvas.getSelectShape();

			if(selectCanvasShape==null)//��֤��ת��ͼ����null
				return;
			transferShape=selectCanvasShape;
	}
	/**
	 * ��������
	 *
	 */
	public void cutObject(){
			CanvasShape selectCanvasShape=canvas.getSelectShape();
			if(selectCanvasShape==null)//��֤��ת��ͼ����null
				return;
			transferShape=selectCanvasShape;
			canvas.removeNowShape(transferShape);
		
	}
	/**
	 * ɾ������
	 *
	 */
	public void deleteObject(){
			CanvasShape selectShape=canvas.getSelectShape();
			if(selectShape==null)
				return;
			items[0].setEnabled(true);//���Գ�����
			canvas.removeNowShape(selectShape);
			undoShapes.addLast(selectShape);//���㳷��
		
	}
	/**
	 * ճ������
	 *
	 */
	public void parseObject(){
			if(transferShape==null)
				return;
			canvas.shapes.addLast(transferShape.clone());

			canvas.repaint();
		
	}
	/**
	 * ����ɾ��������
	 *
	 */
	public void undoObeject(){
		if(undoShapes.size()>0){
			if(undoShapes.size()>10)//���У����Ϳ��Իָ�10����ɾ����ͼ
				canvas.shapes.removeFirst();
			canvas.shapes.add(undoShapes.pollLast());//������ɾ���Ķ����ָ�
			canvas.repaint();
		}
	}
	
}
