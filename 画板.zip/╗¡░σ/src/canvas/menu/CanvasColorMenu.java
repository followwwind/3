package canvas.menu;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JColorChooser;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import canvas.toolkit.Canvas;
/**
 * ��ɫ�˵�
 * @author Administrator
 *
 */
public class CanvasColorMenu extends JMenu implements ActionListener{
	JMenuItem selectColor=new JMenuItem("��ɫ�༭(E)");
	private Canvas canvas; 
	
	
	public CanvasColorMenu(Canvas canvas) {
		super("��ɫ(C)");
		this.canvas=canvas;
		
		add(selectColor);
		selectColor.setMnemonic('E');
		setMnemonic('C');
		selectColor.addActionListener(this);
		
		ImageIcon editColorIcon=new ImageIcon(CanvasHelpMenu.class.getClassLoader().getResource("Icons/editcolor.gif"));
		selectColor.setIcon(editColorIcon);
	}

	public void actionPerformed(ActionEvent e) {
		Color c=JColorChooser.showDialog(canvas, "��ɫ�༭", canvas.getForeground());
		if(c==null)
			return;
		canvas.setNowforeColor(c);
		
	}
	
}
