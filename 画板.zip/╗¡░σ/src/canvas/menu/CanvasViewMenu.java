package canvas.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import canvas.toolkit.Canvas;
/**
 * 
 * �鿴�˵�
 *
 */
public class CanvasViewMenu extends JMenu implements ActionListener{
	
	private JCheckBoxMenuItem tookitBox=new JCheckBoxMenuItem("������(T)");
	private JCheckBoxMenuItem colorBox=new JCheckBoxMenuItem("���Ϻ�(S)");
	private Canvas canvas; 
	public CanvasViewMenu(Canvas canvas) {
		super("�鿴(V)");
		this.canvas=canvas;
		
		add(tookitBox);
		add(colorBox);
		setMnemonic('V');
		tookitBox.setMnemonic('T');
		tookitBox.setActionCommand("tool");
		colorBox.setMnemonic('S');
		colorBox.setActionCommand("color");
		tookitBox.setSelected(true);
		colorBox.setSelected(true);
		
		ImageIcon toolImage=new ImageIcon(CanvasViewMenu.class.getClassLoader().getResource("Icons/toolbox.gif"));
		ImageIcon colorImage=new ImageIcon(CanvasViewMenu.class.getClassLoader().getResource("Icons/colorbox.gif"));
		tookitBox.setIcon(toolImage);
		colorBox.setIcon(colorImage);
		
		tookitBox.addActionListener(this);
		colorBox.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		JCheckBoxMenuItem menuItem=(JCheckBoxMenuItem)e.getSource();
		if(e.getActionCommand().equals("tool")){
			if(menuItem.getState())
				canvas.toolBox.setVisible(true);
			else
				canvas.toolBox.setVisible(false);
		}else{
			if(menuItem.getState())
				canvas.colorBox.setVisible(true);
			else
				canvas.colorBox.setVisible(false);
		}
		
	}
	
}
