package canvas.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import canvas.CanvasWindow;
import canvas.toolkit.Canvas;
/**
 * �����˵�
 * @author Administrator
 *
 */
public class CanvasHelpMenu extends JMenu implements ActionListener{
	JMenuItem helper=new JMenuItem("����(A)");
	Canvas canvas=null;
	public CanvasHelpMenu(Canvas canvas) {
		super("����(H)");
		this.canvas=canvas;
		add(helper);
		setMnemonic('H');
		helper.setMnemonic('A');
		helper.addActionListener(this);
		ImageIcon helpIcon=new ImageIcon(CanvasHelpMenu.class.getClassLoader().getResource("Icons/about.gif"));
		helper.setIcon(helpIcon);
	}

	public void actionPerformed(ActionEvent e) {
		String message="copyright(c) 2008 ����\n���ߣ������";
		JOptionPane.showMessageDialog(canvas, message, "���ڻ���", JOptionPane.INFORMATION_MESSAGE);
	}
}
