package canvas.menu;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

import canvas.model.shape.CanvasImage;
import canvas.toolkit.Canvas;

public class CanvasImageMenu extends JMenu implements ActionListener{
	private JMenuItem scaleImage=new JMenuItem("���췭ת(S)");
	private JMenuItem printScreen=new JMenuItem("����(P)");
	private JMenuItem clearImage=new JMenuItem("���(C)");
	private Canvas canvas;
	
	public CanvasImageMenu(Canvas canvas) {
		super("ͼ��(I)");
		setMnemonic('I');
		
		this.canvas=canvas;
		scaleImage.setMnemonic('S');
		printScreen.setMnemonic('P');
		clearImage.setMnemonic('C');
		
		scaleImage.addActionListener(this);//�Ӽ���
		printScreen.addActionListener(this);
		clearImage.addActionListener(this);
		
		ImageIcon scale_icon=new ImageIcon(CanvasImageMenu.class.getClassLoader().getResource("Icons/scale.gif"));
		ImageIcon print_icon=new ImageIcon(CanvasImageMenu.class.getClassLoader().getResource("Icons/printscreen.gif"));
		ImageIcon clear_icon=new ImageIcon(CanvasImageMenu.class.getClassLoader().getResource("Icons/clear.gif"));
		
		scaleImage.setIcon(scale_icon);
		printScreen.setIcon(print_icon);
		clearImage.setIcon(clear_icon);
		
		
		scaleImage.setActionCommand("scale");
		printScreen.setActionCommand("print");
		clearImage.setActionCommand("clear");
		
		//������ݼ�
		printScreen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, KeyEvent.CTRL_DOWN_MASK));
		
		add(scaleImage);
		add(clearImage);
		add(clearImage);
		addSeparator();
		add(printScreen);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("scale")){
			showScaleDialog();
		}else if(e.getActionCommand().equals("print")){
			printScreen();
		}else{
			clearImage();
		}
		canvas.repaint();
		
	}
	/**
	 * ��ʾ����Ի�����ܰ��ʾ
	 *
	 */
	public void showScaleDialog(){
		String msg="��������϶�ͼ�ε����·����������ת����ע��Ǧ�ʺͷ�ն����״�ǲ������췭ת��";
		JOptionPane.showMessageDialog(canvas,msg , "��ܰ��ʾ", JOptionPane.INFORMATION_MESSAGE);
	}
	/**
	 * ����
	 *
	 */
	public void printScreen() {
		Robot r=null;
		try {
			r=new Robot();
		} catch (AWTException e) {
			e.printStackTrace();
		}
		
		Toolkit t=Toolkit.getDefaultToolkit();
		Dimension size=t.getScreenSize();
		BufferedImage screenImage=r.createScreenCapture(new Rectangle(0,0,size.width,size.height));

		canvas.shapes.add(new CanvasImage(0,0,canvas.getWidth(),canvas.getHeight(),screenImage));
	}
	/**
	 * �������ͼ��
	 *
	 */
	public void clearImage(){
		canvas.shapes.clear();
		canvas.pasters.clear();
		canvas.texts.clear();
		canvas.brushes.clear();
		canvas.canvasMask = null;
		canvas.setBackground(canvas.colorBox.getBackColor());
	}
	
}
