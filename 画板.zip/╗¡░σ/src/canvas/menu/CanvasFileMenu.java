package canvas.menu;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.filechooser.FileNameExtensionFilter;

import canvas.CanvasWindow;
import canvas.model.shape.CanvasImage;
import canvas.model.shape.CanvasShape;
import canvas.toolkit.Canvas;

/**
 * �ļ��˵�
 */
public class CanvasFileMenu extends JMenu implements ActionListener,
		MouseListener {
	private String[] fileItemLabels = { "�½�(N)", "��(O)", "����(S)", "����Ϊ(A)",
			"�˳�(X)" };
	
	private String[] tipTexts = { "new", "open", "save", "saveAs", "exit" };

	private JMenuItem[] fileItems = new JMenuItem[fileItemLabels.length];
	private ImageIcon[] icons=new ImageIcon[tipTexts.length];
	private JCheckBoxMenuItem fullScreenItem=new JCheckBoxMenuItem("ȫ��Ļ(F)",false);
	
	private char[] memerys = { 'N', 'O', 'S', 'A', 'X' };

	private Canvas canvas;

	private boolean isSave = false;

	private File currentFile = null;// �����ļ�ʱ������Ѿ����棬�Ͱ���������ֱ��������ļ���

	private BufferedImage saveImage = null;

	public CanvasFileMenu(Canvas canvas) {
		super("�ļ�(F)");
		this.canvas = canvas;
		for (int i = 0; i < fileItemLabels.length; i++) {
			fileItems[i] = new JMenuItem(fileItemLabels[i]);
			fileItems[i].setMnemonic(memerys[i]);
			fileItems[i].setToolTipText(tipTexts[i]);
			fileItems[i].addActionListener(this);
			fileItems[i].setActionCommand(tipTexts[i]);
			add(fileItems[i]);
			if (i == 3 ){
				addSeparator();
				add(fullScreenItem);
				addSeparator();
			}
		}
		//�½�
		fileItems[0].setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, KeyEvent.CTRL_DOWN_MASK));
		//��
		fileItems[1].setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, KeyEvent.CTRL_DOWN_MASK));
		//����
		fileItems[2].setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, KeyEvent.CTRL_DOWN_MASK));
		
		for(int i=0;i<icons.length;i++){
			icons[i]=new ImageIcon(CanvasFileMenu.class.getClassLoader().getResource("Icons/"+tipTexts[i]+".gif"));
			fileItems[i].setIcon(icons[i]);
		}
		
		ImageIcon  full_screen=new ImageIcon(CanvasFileMenu.class.getClassLoader().getResource("Icons/full.gif"));
		
		fullScreenItem.setToolTipText("fullScreen");
		fullScreenItem.setActionCommand("fullScreen");
		fullScreenItem.addActionListener(this);
		fullScreenItem.setMnemonic('F');
		fullScreenItem.setIcon(full_screen);
		
		setMnemonic('F');
		addMouseListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("new")) {
			CanvasWindow.FrameOwn.setTitle("δ����  ����");
			isSave = false;// �½����ļ���û������
			canvas.shapes.clear();
			canvas.setBackground(canvas.colorBox.getBackColor());
		} else if (e.getActionCommand().equals("open")) {
			openFile();
		} else if (e.getActionCommand().equals("save")) {
			saveFile();
		} else if (e.getActionCommand().equals("saveAs")) {
			saveAsFile();
		} else if (e.getActionCommand().equals("fullScreen")) {
			fullScreen();
		} else if (e.getActionCommand().equals("exit")) {// �˳�
			System.exit(0);
		}

		canvas.repaint();
	}

	public void fullScreen(){//ע�Ͳ�������ȫ���ٶȼ���,������ת�ķ���
		/*GraphicsEnvironment ge=GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice gd=ge.getDefaultScreenDevice();*/
		if(fullScreenItem.getState()){
			/*CanvasWindow.FrameOwn.dispose();
			CanvasWindow.FrameOwn.setUndecorated(true);
			gd.setFullScreenWindow(CanvasWindow.FrameOwn);//ȫ��Ļ
			CanvasWindow.FrameOwn.createBufferStrategy(2);*/
			
			CanvasWindow.FrameOwn.dispose();
			CanvasWindow.FrameOwn.setUndecorated(true);
			Dimension size=Toolkit.getDefaultToolkit().getScreenSize();
			Rectangle bounds=new Rectangle(size);
			CanvasWindow.FrameOwn.setBounds(bounds);
			CanvasWindow.FrameOwn.setVisible(true);
		}else{
			/*CanvasWindow.FrameOwn.dispose();
			CanvasWindow.FrameOwn.setUndecorated(false);
			gd.setFullScreenWindow(null);//�ָ�
			CanvasWindow.FrameOwn.setVisible(true);*/
			
			CanvasWindow.FrameOwn.dispose();
			CanvasWindow.FrameOwn.setUndecorated(false);
			CanvasWindow.FrameOwn.setLocation(200, 100);
			CanvasWindow.FrameOwn.pack();
			CanvasWindow.FrameOwn.setVisible(true);
		}
	}
	
	/**
	 * ͼƬ����Ϊ
	 *
	 */
	public void saveAsFile(){
		try{
			isSave = true;
			JFileChooser fileChooser = new JFileChooser(".");
			FileNameExtensionFilter filter = new FileNameExtensionFilter(
					"Gif&JPG File", "gif", "jpg");
			fileChooser.setFileFilter(filter);
			int returnVal = fileChooser.showSaveDialog(canvas);
			
			if (returnVal == JFileChooser.APPROVE_OPTION) {// ѯ�ʱ���������
				currentFile = fileChooser.getSelectedFile();
				CanvasWindow.FrameOwn.setTitle(currentFile.getName());
				if(currentFile.exists()){
					int temp=JOptionPane.showConfirmDialog(canvas, "�ļ��Ѿ������Ƿ񸲸ǣ�", "�ļ��Ѵ���", JOptionPane.WARNING_MESSAGE);
					if(temp==JOptionPane.YES_OPTION){
						ImageIO.write(saveImage, "jpg", currentFile);
					}else//��û�д洢ͼƬ
						isSave=false;
				}else
					ImageIO.write(saveImage, "jpg", currentFile);
			}else//��û�洢ͼƬ
				isSave=false;
	
			
		}catch(IOException e){
			System.err.println("ͼ���������");
		}
	}
	
	
	/**
	 * ���ļ�
	 * 
	 */
	public void openFile() {
		File imageFile = null;
		BufferedImage buffSrc = null;
		JFileChooser fileChooser = new JFileChooser(".");
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
				"Gif&JPG File", "gif", "jpg");
		fileChooser.setFileFilter(filter);
		int returnVal = fileChooser.showOpenDialog(canvas);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			imageFile = fileChooser.getSelectedFile();
			CanvasWindow.FrameOwn.setTitle(imageFile.getName());
			try {
				buffSrc = ImageIO.read(imageFile);
			} catch (IOException e) {
				e.printStackTrace();
			}
			int srcHeight = buffSrc.getHeight();
			int srcWidth = buffSrc.getWidth();

			// ���ͼ����ڻ���ߴ磬�Ͱ�������Ϊ����ߴ�
			if (srcHeight > canvas.getCanvasHeight() - 2
					|| srcWidth > canvas.getCanvasWidth() - 2) {// ��������ͼƬ���ڻ���ĳߴ�
				int newHeight = canvas.getCanvasHeight();
				int newWidth = canvas.getCanvasWidth();
				CanvasShape cs = new CanvasImage(0, 0, newWidth, newHeight,
						buffSrc);
				canvas.shapes.add(cs);
			} else {
				CanvasShape cs = new CanvasImage(0, 0, srcWidth, srcHeight,
						buffSrc);
				canvas.shapes.add(cs);
			}
		}

	}

	/**
	 * �����ļ�
	 */
	public void saveFile(){
		try{
			if (!isSave) {//û����
				isSave = true;
				JFileChooser fileChooser = new JFileChooser(".");
				FileNameExtensionFilter filter = new FileNameExtensionFilter(
						"Gif&JPG File", "gif", "jpg");
				fileChooser.setFileFilter(filter);
	
				int returnVal = fileChooser.showSaveDialog(canvas);
	
				if (returnVal == JFileChooser.APPROVE_OPTION) {// ѯ�ʱ���������
					CanvasWindow.FrameOwn.setTitle(fileChooser.getSelectedFile().getName());
					currentFile = fileChooser.getSelectedFile();
					if(currentFile.exists()){
						int temp=JOptionPane.showConfirmDialog(canvas, "�ļ��Ѿ������Ƿ񸲸ǣ�", "�ļ��Ѵ���", JOptionPane.WARNING_MESSAGE);
						if(temp==JOptionPane.YES_OPTION){
							ImageIO.write(saveImage, "jpg", currentFile);
						}else//��û�д洢ͼƬ
							isSave=false;
					}else//û�д��ھ�ֱ�����
						ImageIO.write(saveImage, "jpg", currentFile);
				}else 
					isSave=false;
	
			} else {//�Ѿ�����
				ImageIO.write(saveImage, "jpg", currentFile);// ֱ�����
			}
		}catch(IOException e){
			System.err.println("ͼ���������");
		}
	}

	public void mouseEntered(MouseEvent e) {//����굽���ļ��˵�����ʱ�򣬾ͽ���
		Robot r = null;
		Point p = canvas.getLocationOnScreen();
		int canvasWidth = canvas.getWidth();
		int canvasHeight = canvas.getHeight();
		try {
			r = new Robot();
		} catch (AWTException event) {
			event.printStackTrace();
		}
		// ������������ͼ��
		saveImage = r.createScreenCapture(new Rectangle(p.x, p.y, canvasWidth,canvasHeight));
		Point pp=e.getPoint();
System.out.println("x:"+pp.x+" y:"+pp.y);		
	}
	
	
	public void mouseClicked(MouseEvent e) {
	}
	public void mouseExited(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
	}

	public void mouseReleased(MouseEvent e) {
	}
}
