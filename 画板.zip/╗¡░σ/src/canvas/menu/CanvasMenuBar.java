package canvas.menu;
import javax.swing.JMenuBar;

import canvas.toolkit.Canvas;
/**
 * �˵���
 * @author Administrator
 *
 */
public class CanvasMenuBar extends JMenuBar{
	
	private CanvasColorMenu colorMenu=null;
	private CanvasHelpMenu helpMenu=null;
	private CanvasFileMenu fileMenu=null;
	private CanvasViewMenu viewMenu=null;
	private CanvasEditMenu editMenu=null;
	private CanvasImageMenu imageMenu=null;
	
	public CanvasMenuBar(Canvas canvas) {		
		initMenu(canvas);
		
		add(fileMenu);
		add(editMenu);
		add(viewMenu);
		add(imageMenu);
		add(colorMenu);
		add(helpMenu);
		
	}
	/**
	 * ��ʼ���˵�
	 * @param canvas ����������Ļ���
	 */
	public void initMenu(Canvas canvas) {
		colorMenu=(CanvasColorMenu)MenuItemFactory.getMenu("canvas.menu.CanvasColorMenu",canvas);
		helpMenu=(CanvasHelpMenu)MenuItemFactory.getMenu("canvas.menu.CanvasHelpMenu",canvas);
		fileMenu=(CanvasFileMenu)MenuItemFactory.getMenu("canvas.menu.CanvasFileMenu",canvas);
		viewMenu=(CanvasViewMenu)MenuItemFactory.getMenu("canvas.menu.CanvasViewMenu",canvas);
		editMenu=(CanvasEditMenu)MenuItemFactory.getMenu("canvas.menu.CanvasEditMenu",canvas);
		imageMenu=(CanvasImageMenu)MenuItemFactory.getMenu("canvas.menu.CanvasImageMenu",canvas);
		
	}
	
}
